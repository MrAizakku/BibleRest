package database;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import beans.Bible;
import beans.BibleSection;

@Stateless @Local @Alternative
public class BibleDataService implements BibleDataInterface {
	Bible bible = new Bible();
	
	@Override
	public BibleSection getFirstOccurance(String word) {
		BibleSection bs = new BibleSection();
		word = word.toLowerCase();
		for(int i = 0; i < bible.getBible().size(); i++) {
			String verse = bible.getBible().get(i).getVerse().toLowerCase();
			if(verse.contains(word)) {
				bs = bible.getBible().get(i);
				break;
			}
		}
		return bs;
	}

	@Override
	public ArrayList<BibleSection> getNumberOfOccurances(String word) {
		ArrayList<BibleSection> bsl = new ArrayList<BibleSection>();
		word = word.toLowerCase();
		for(int i = 0; i < bible.getBible().size(); i++) {
			String verse = bible.getBible().get(i).getVerse().toLowerCase();
			if(verse.contains(word)) {
				bsl.add(bible.getBible().get(i));
			}
		}
		return bsl;
	}

	@Override
	public BibleSection getVerse(String bookName, String ChapterNo, String verseNo) {
		BibleSection bs = new BibleSection();
		bookName = bookName.toLowerCase();
		for(int i = 0; i < bible.getBible().size(); i++) {
			BibleSection current = bible.getBible().get(i);
			if(current.getBook_name().toLowerCase().equals(bookName) && current.getChapter_number().toLowerCase().equals(ChapterNo) && current.getVerse_number().toLowerCase().equals(verseNo)) {
				bs = bible.getBible().get(i);
				break;
			}
		}		
		return bs;
	}

	@Override
	public Bible parseXML() {
		bible = new Bible();
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse("C:/Users/ASUS/jboss-eap-7.1/standalone/deployments/BibleREST.war/WEB-INF/classes/bible.xml");
			NodeList bible_list = doc.getElementsByTagName("bible");
			for(int i = 0; i < bible_list.getLength(); i++) {
				Node bible_node = bible_list.item(i);
				if(bible_node.getNodeType()==Node.ELEMENT_NODE) {
					Element bible_ele = (Element) bible_node;
					NodeList book_list = bible_ele.getChildNodes();
					for(int j = 0; j < book_list.getLength(); j++) {
						Node book_node = book_list.item(j);
						if(book_node.getNodeType() == Node.ELEMENT_NODE) {
							Element book_element = (Element) book_node;
							String book = book_element.getAttribute("n");
							NodeList chapter_list = book_element.getChildNodes();
							for(int k = 0; k < chapter_list.getLength(); k++) {
								Node chapter_node = chapter_list.item(k);
								if(chapter_node.getNodeType() == Node.ELEMENT_NODE) {
									Element chapter_element = (Element) chapter_node;
									String chapter_number = chapter_element.getAttribute("n");
									NodeList verse_list = chapter_element.getChildNodes();
									for(int l = 0; l < verse_list.getLength(); l++) {
										Node verse_node = verse_list.item(l);
										if(verse_node.getNodeType() == Node.ELEMENT_NODE) {
											Element verse_element = (Element) verse_node;
											String verse_number = verse_element.getAttribute("n");
											String verse = verse_element.getTextContent();
											BibleSection bs = new BibleSection(book, chapter_number, verse_number, verse);
											bible.getBible().add(bs);
										}
									}
								}
							}
						}
					}  
				}
			}
		} catch (ParserConfigurationException e) {
			System.out.println("ERROR1");
			e.printStackTrace();
		} catch (SAXException e) {
			System.out.println("ERROR2");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("ERROR3");
			e.printStackTrace();
		}	
		return bible;
	}
	
	public void testPath() {
	    URL localPackage = this.getClass().getResource("");
	    URL urlLoader = BibleDataService.class.getProtectionDomain().getCodeSource().getLocation();
	    String localDir = localPackage.getPath();
	    String loaderDir = urlLoader.getPath();
	    System.out.printf("loaderDir = %s\n localDir = %s\n", loaderDir, localDir);	
	}

	public Bible getBible() {
		return bible;
	}
}
