package database;

import java.util.ArrayList;

import javax.ejb.Local;
import javax.enterprise.inject.Alternative;
import beans.Bible;
import beans.BibleSection;

@Local @Alternative
public interface BibleDataInterface {
	public BibleSection getFirstOccurance(String word);
	public ArrayList<BibleSection> getNumberOfOccurances(String word);
	public BibleSection getVerse(String bookName, String ChapterNo, String verseNo);
	public Bible parseXML();
	public void testPath();
	public Bible getBible();
}
