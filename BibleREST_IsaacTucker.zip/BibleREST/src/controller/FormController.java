package controller;

import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import beans.Bible;
import business.BibleBusinessInterface;

@ManagedBean
public class FormController {
	@Inject
	BibleBusinessInterface bbi;
	
	public void onLoad() {
		bbi.testPath();
		Bible b = bbi.parseXML();
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("bible", b);
	}
	
	public void onSize() {
		System.out.println("The ArrayList size is " + bbi.getBible().getBible().size());
	}
}
