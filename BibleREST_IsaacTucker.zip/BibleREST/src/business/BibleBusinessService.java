package business;

import java.util.ArrayList;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import javax.inject.Inject;

import beans.Bible;
import beans.BibleSection;
import database.BibleDataInterface;

@Local @Stateless @Alternative
public class BibleBusinessService implements BibleBusinessInterface {

	@Inject
	BibleDataInterface bdi;
	
	@Override
	public BibleSection getFirstOccurance(String word) {
		return bdi.getFirstOccurance(word);
	}

	@Override
	public ArrayList<BibleSection> getNumberOfOccurances(String word) {
		return bdi.getNumberOfOccurances(word);
	}

	@Override
	public BibleSection getVerse(String bookName, String ChapterNo, String verseNo) {
		return bdi.getVerse(bookName, ChapterNo, verseNo);
	}

	@Override
	public Bible parseXML() {
		return bdi.parseXML();
	}

	@Override
	public void testPath() {
		bdi.testPath();
	}

	@Override
	public Bible getBible() {
		return bdi.getBible();
	}

}
