package business;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import beans.BibleSection;

@RequestScoped
@Path("/bible")
@Produces("application/xml")
@Consumes("application/xml")
public class BibleRestService {

	@Inject
	BibleBusinessInterface bbi;
	
	//get all records
	@GET
	@Path("/getxml")
	@Produces(MediaType.APPLICATION_XML)
	public BibleSection[] getBibleFromXML() {
		List<BibleSection> bs = bbi.parseXML().getBible();
		return bs.toArray(new BibleSection[bs.size()]);
	}
	
	//get all records
	@GET
	@Path("/getxmlword/{word}/")
	@Produces(MediaType.APPLICATION_XML)
	public BibleSection[] getFirstOccurance(@PathParam("word") String word) {
		List<BibleSection> bs = new ArrayList<BibleSection>();
		BibleSection biblesection = bbi.getFirstOccurance(word);
		bs.add(biblesection);
		return bs.toArray(new BibleSection[bs.size()]);
	}
	
	//get all records
	@GET
	@Path("/getxmlwords/{word}/")
	@Produces(MediaType.APPLICATION_XML)
	public BibleSection[] getNumberOfOccurances(@PathParam("word") String word) {
		List<BibleSection> bs = bbi.getNumberOfOccurances(word);
		return bs.toArray(new BibleSection[bs.size()]);
	}
	
	//get all records
	@GET
	@Path("/getxmlverse/{book}/{chapter}/{verse}")
	@Produces(MediaType.APPLICATION_XML)
	public BibleSection[] getVerse(@PathParam("book") String book, @PathParam("chapter") String chapter, @PathParam("verse") String verse) {
		List<BibleSection> bs = new ArrayList<BibleSection>();
		BibleSection biblesection = bbi.getVerse(book, chapter, verse);
		bs.add(biblesection);
		return bs.toArray(new BibleSection[bs.size()]);
	}
}
