package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.xml.bind.annotation.XmlRootElement;

@SessionScoped @ManagedBean
@XmlRootElement(name="BibleSection")
public class BibleSection {
	String book_name, chapter_number, verse_number, verse;
	
	public BibleSection() {}

	public BibleSection(String book_name, String chapter_number, String verse_number, String verse) {
		super();
		this.book_name = book_name;
		this.chapter_number = chapter_number;
		this.verse_number = verse_number;
		this.verse = verse;
	}

	public String getBook_name() {
		return book_name;
	}

	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}

	public String getChapter_number() {
		return chapter_number;
	}

	public void setChapter_number(String chapter_number) {
		this.chapter_number = chapter_number;
	}

	public String getVerse_number() {
		return verse_number;
	}

	public void setVerse_number(String verse_number) {
		this.verse_number = verse_number;
	}

	public String getVerse() {
		return verse;
	}

	public void setVerse(String verse) {
		this.verse = verse;
	}
	
}
