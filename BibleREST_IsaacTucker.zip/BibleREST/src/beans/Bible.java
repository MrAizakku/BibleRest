package beans;

import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@SessionScoped @ManagedBean
public class Bible {
	ArrayList<BibleSection> bible = new ArrayList<BibleSection>();
	
	public Bible() {}

	public ArrayList<BibleSection> getBible() {
		return bible;
	}

	public void setBible(ArrayList<BibleSection> bible) {
		this.bible = bible;
	}
	
	
	
}
